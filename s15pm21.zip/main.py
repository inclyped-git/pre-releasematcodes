#A data logger records the temperature on the roof of a school twice a day, at midday and midnight. Input and store the temperatures recorded for a month. You must store the temperatures in two one dimensional arrays, one for the midday temperatures and one for the midnight temperatures. All the temperatures must be validated on entry and any invalid temperatures rejected. You must decide your own validation rules. You may assume that there are 30 days in a month.

#Arrays for storing temperatures
md_temp = [] #Midday
mn_temp = [] #Midnight

#Loop for entering 30 times (since it is 30 days!)
#day section here.
for i in range(30):
  day_temp = input("Please enter the day temperature:")
  if day_temp.isnumeric() == True:
    day_temp = int(day_temp)
    if day_temp < 100:
      md_temp.append(day_temp)
      print("Value inserted:", day_temp)
      print("Overall day database:", md_temp)
    else:
      print("Value is too high!")
      md_temp.append("-")
      print("Value inserted:", day_temp)
      print("Overall day database:", md_temp)

  else:
    print("Value entered is wrong!")
    md_temp.append("-")
    print("Value inserted:", day_temp)
    print("Overall day database:", md_temp)
#night section here.
  night_temp = input("Please enter the night temperature:")
  if night_temp.isnumeric() == True:
    night_temp = int(night_temp)
    if night_temp < 100:
      mn_temp.append(night_temp)
      print("Value inserted:", night_temp)
      print("Overall night database:", mn_temp)
    else:
      print("Value is too high!")
      mn_temp.append("-")
      print("Value inserted:", night_temp)
      print("Overall night database:", mn_temp)

  else:
    print("Value entered is wrong!")
    mn_temp.append("-")
    print("Value inserted:", night_temp)
    print("Overall night database:", mn_temp)

print("Day temperatures:", md_temp)
print("Night temperatures:", mn_temp)


#Calculate the average temperature for midday and the average temperature for midnight. Output these averages with a suitable message for each one.

#assigning sums before loop.
sum_day = 0
sum_night = 0

#first have to convert "-" into 0s.
for i in range(len(md_temp)):
  if md_temp[i] == "-":
    md_temp[i] = 0

for i in range(len(mn_temp)):
  if mn_temp[i] == "-":
    mn_temp[i] = 0

#now the mean is calculated.
sum_rep = 0
for i in range(len(md_temp)):
  sum_day = sum_day + md_temp[i]
  sum_rep = sum_rep + 1
print("Average day temperature:", int((sum_day / sum_rep)))


for i in range(len(mn_temp)):
  sum_night = sum_night + mn_temp[i]
print("Average night temperature:", int((sum_night / sum_rep)))

#Select the day with the highest midday temperature and the day with the lowest midnight temperature. Then output each of these temperatures, the corresponding day and a suitable message.

#initially assigning high temp to first element of the array.
high_dayt = md_temp[0]
for i in range(1,2):
  if high_dayt < md_temp[i]:
    high_dayt = md_temp[i]
  else:
    break
print("Highest day temperature:", high_dayt)

#initially assigning low temp to first element of the array.
low_nightt = mn_temp[0]
for i in range(1,2):
  if low_nightt > mn_temp[i]:
    low_nightt = mn_temp[i]
  else:
    break
print("Lowest night temperature:", low_nightt)

print("__________________________")
print("Code ended, please come back again!")

#Code ended...
#Check pre-release material in the 2015-codes repository. 